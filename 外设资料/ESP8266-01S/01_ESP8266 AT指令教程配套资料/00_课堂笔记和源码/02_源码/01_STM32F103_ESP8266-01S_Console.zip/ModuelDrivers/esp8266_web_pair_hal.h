/*
 * ESP8266_WEB_PAIR_HAL.h
 *
 *  Created on: 1-June-2021
 *      Author: biubiu
 */


#ifndef ESP8266_WEB_PAIR_HAL_H_
#define ESP8266_WEB_PAIR_HAL_H_

#include "stm32f1xx_hal.h"

uint8_t esp_web_pair_init (char *SSID, char *PASSWD);


#endif /* ESP8266_WEB_PAIR_HALH_ */
