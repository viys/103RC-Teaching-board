/*
 * ESP8266_HAL.h
 *
 *  Created on: 1-June-2021
 *      Author: biubiu
 */


#ifndef INC_ESP8266_HAL_H_
#define INC_ESP8266_HAL_H_

void esp_web_hw_ctrl_init (char *ssid, char *passwd);
void esp_web_hw_ctrl_server_start (void);
void esp_web_hw_ctrl_server_start (void);



#endif /* INC_ESP8266_HAL_H_ */
