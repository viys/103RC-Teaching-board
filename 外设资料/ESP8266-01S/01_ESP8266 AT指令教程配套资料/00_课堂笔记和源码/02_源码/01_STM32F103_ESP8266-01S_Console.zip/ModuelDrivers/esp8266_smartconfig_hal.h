/*
 * ESP8266_WEB_PAIR_HAL.h
 *
 *  Created on: 23-June-2021
 *      Author: biubiu
 */


#ifndef ESP8266_SMARTCONFIG_HAL_H_
#define ESP8266_SMARTCONFIG_HAL_H_

void esp8266_smartconfig_init(void);

#endif /* ESP8266_SMARTCONFIG_HAL_H_ */
