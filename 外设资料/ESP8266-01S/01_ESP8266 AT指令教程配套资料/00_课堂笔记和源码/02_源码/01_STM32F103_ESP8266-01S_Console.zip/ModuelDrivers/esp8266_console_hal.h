/*
 *  esp8266_console_hal.h
 *
 *  Created on: June 11, 2021
 *      Author: biubiu
 */


#ifndef INC_ESP8266_CONSOLE_HAL_H_
#define INC_ESP8266_CONSOLE_HAL_H_


void esp8266_console_Init(void);
void esp_console_start(void);


#endif /* INC_ESP8266_CONSOLE_HAL_H_ */
